# Copyright (c) 2022, Frappe Technologies Pvt Ltd and Contributors
# See license.txt

# import frappe
import unittest


class TestGPTask(unittest.TestCase):
	pass
