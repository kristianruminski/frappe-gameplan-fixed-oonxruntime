<template>
  <div class="h-full p-3 text-base text-ink-gray-7">Coming soon</div>
</template>
<script>
export default {
  name: 'ComingSoon',
}
</script>
